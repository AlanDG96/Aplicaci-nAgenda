package com.example.agendas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class sActivity extends AppCompatActivity {

    private EditText user;
    private EditText email;
    private EditText twitter;
    private EditText tel;
    private EditText fecha;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_s);

        user = (EditText) findViewById(R.id.etxtUser);
        email = (EditText) findViewById(R.id.etxtEmail);
        twitter = (EditText) findViewById(R.id.etxtTwitter);
        tel = (EditText) findViewById(R.id.etxtTel);
        fecha = (EditText) findViewById(R.id.etxtFecNac);
    }

    public void Save(View View){
        Contacto obj = new Contacto(user.getText().toString(), email.getText().toString(), twitter.getText().toString(), tel.getText().toString(), fecha.getText().toString());
        Intent Save = new Intent(this,MainActivity.class);
        Save.putExtra("con", obj);
        setResult(MainActivity.RESULT_OK, Save);
        finish();
    }

    public void Cancel(View View){
        Intent Cancel = new Intent(this, MainActivity.class);
        setResult(MainActivity.RESULT_CANCELED, Cancel);
        finish();
    }
}
