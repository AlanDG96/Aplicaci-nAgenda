package com.example.agendas;

import java.io.Serializable;

public class Contacto implements Serializable {
    private String usuario;
    private String email;
    private String twitter;
    private String tel;
    private String fecha;

    public Contacto(String usuario, String email, String twitter, String tel, String fecha){
        this.usuario = usuario;
        this.email = email;
        this.twitter = twitter;
        this.tel = tel;
        this.fecha = fecha;
    }

    public String message(){
        return this.usuario + "\n" + this.email;
    }

}