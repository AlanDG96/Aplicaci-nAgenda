package com.example.agendas;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<Contacto> lista;
    private Contacto con;
    private int request;
    private ListView listView;
    private TextView Agrega;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lista = new ArrayList<>();
        Agrega = (TextView)findViewById(R.id.txtAdd);
        Agrega.setText(lista.size()+"");
        Show();
    }

    public void Next(View View){
        Intent next = new Intent(this, sActivity.class);
        startActivityForResult(next, request);
    }

    public void Show(){
        listView = (ListView) findViewById(R.id.lstList);
        ArrayList<String> list = new ArrayList<>();
        for (int i=0; i<lista.size(); i++){
            list.add(lista.get(i).message());
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,list);
        listView.setAdapter(adapter);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (resultCode==MainActivity.RESULT_OK){
            con = (Contacto) data.getSerializableExtra("con");
            lista.add(con);
            Agrega.setText(lista.size()+"");
            Show();
        }
    }
}
